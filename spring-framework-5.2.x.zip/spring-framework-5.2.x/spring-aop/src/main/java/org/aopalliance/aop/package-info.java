/**
 * The core AOP Alliance advice marker.
 */
package org.aopalliance.aop;
